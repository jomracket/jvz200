If you're using Notepad, turn on wordwrap.

These .CVZ files are VZ200-format cassette files.

To use them with James's VZ200, type CLOAD, and press RETURN when prompted to do so.

From the File menu, select Play Cassette File, and choose the .CVZ file you want.

The "Demo" programs were on the demo tape that was bundled with the actual NTSC VZ200 in the United States.

The "Introbas" programs were sold on a separate cassette.  Note that these BASIC programs were probably originally intended for a 40 column/25 row screen format, and so the screen formatting sucks, but that's the way they came if you'd bought the cassette back in the early 1980s.  Would you like to fix them?

==

.CVZ files can be converted back to WAV files which a real VZ200 can use, by using the CVZTOWAV program in the Tools directory.
