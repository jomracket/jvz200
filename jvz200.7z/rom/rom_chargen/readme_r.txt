Turn Word Wrap ON if you're using Notepad.


======

match_chr.bin is a simulated 768 byte character ROM, based on the NEC TREK's external character set image.

mess_ntscround_chr.bin is a simulated 768 byte character ROM, looted from MESS.

mess_ntscsquare_chr.bin is a simulated 768 byte character ROM, looted from MESS.
