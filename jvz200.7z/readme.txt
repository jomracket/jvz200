Turn Word Wrap ON if you're using Notepad.

See also the readme.txt in the docs directory.

This is the Quick Start document.

First, unzip all the files into a directory, e.g. c:\JVZ200.

Cool.

Then double-click on the JVZ200 icon.

The emulator should now be running.

Type cload and press the ENTER key on your keyboard.

You should see the word "WAITING" at the bottom of the emulator screen.

From the FILE menu, select Play Cassette File, and when the file requester pops up, browse down into the DEMO directory.  Choose the file A_DEMO_TAPE_BAS.CVZ

When the blinking cursor reappears, type run and press the ENTER key.

The words "DEMONSTRATION TAPE" will appear.  So will "WAITING."  It is waiting for another cassette file.  From the FILE menu, select Play Cassette File, and when the file requester pops up, choose the file B_WELCOME_BAS.CVZ

In turn, each time you see the "WAITING" at the bottom of the screen, choose the file which begins with the next letter of the alphabet (e.g. the next one would be C_CHAR_SET_BAS.CVZ, and then after that D_BAR_CHART_1_BAS.CVZ, etc.).

==

After you've watched the demo (all the way through R_END_BAS.CVZ), go and read the readme.txt that's in the DOCS directory!

You'll find that you can load and save BASIC programs, and you can run the .VZ game files that were made for the other VZ200 emulators.

To find out more about the VZ200 computer, steer your internet browser toward:

  VZ Alive!
        vzalive.bangrocks.com

  Guy Thomason's VZ200 Resource Page
        http://homepage.powerup.com.au/~intertek/VZ200/vz.htm

  Planet VZ
        http://www.fortunecity.com/skyscraper/laser/184/

  The Yahoo group:
        http://games.groups.yahoo.com/group/vzemu/


Enjoy!
James the Animal Tamer
2002
www.geocities.com/emucompboy

