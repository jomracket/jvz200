Files in this directory are in the .vz format.  I didn't make them so I can't vouch for their faithfulness to the originals (and some do appear to be hacked/cracked).

The .vz format is a software program format which is neither cassette nor cartridge image nor snapshot.  Its main advantage is that it loads quickly.

To use these with James's VZ200, from the UTIL menu, select "Load .VZ" and then from the file selector pick the .vz file to load.  Programs in the "autostart" directories will start automatically.  For programs in the "run" directories, you will have to type RUN to get them going.


These files were downloaded from these websites:
  VZ Alive!
        vzalive.bangrocks.com

  Guy Thomason's VZ200 Resource Page
        http://homepage.powerup.com.au/~intertek/VZ200/vz.htm

  Planet VZ
        http://www.fortunecity.com/skyscraper/laser/184/

  The Yahoo group:
        http://games.groups.yahoo.com/group/vzemu/

There's lots more info and goodies on those websites.  Point your browser and give them a visit!
