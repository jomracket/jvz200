A few tools to help you work with the emulator.

========================

MONOWAV - This program takes a stereo WAV file and cuts it into two mono WAV files.  The new mono WAV files are named name_ML.wav and name_MR.wav.

-
monowav program by James the Animal Tamer
========================

CVZTOWAV - This program takes a good .cvz file and converts it into a WAV file.  The WAV file can be used with a real VZ200 computer.  It's a Windows program -- double click the icon to open it and get started.  
	It can also process a .vz file that originated from tape.  Note: the .vz file format has no checksums or other data integrity checks, so there's no way of telling whether or not a .vz file is/was good.  Caveat emptor and GIGO (garbage in/garbage out).

-
cvztowav program by James the Animal Tamer
========================
